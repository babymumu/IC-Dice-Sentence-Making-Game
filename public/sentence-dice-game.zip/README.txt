============================================================
Sentence Dice 句子骰子 - Classroom Chinese Learning Game
============================================================

HOW TO USE / 使用说明:

Option 1 (Easiest - Single File / 最简单直接双击打开):
- Simply double-click "sentence_dice_standalone.html" in any web browser 
  (Chrome, Safari, Edge, Firefox, Smartboard browser).
  No server or installation required! Works completely offline.

Option 2 (Standard Web Folder / 网页文件夹):
- Open "index_relative.html" or host the folder on any classroom web server.

Features included:
- Tactile 3D tumbling Chinese dice for all 6 categories (Subject, Time, Location, Modifier, Verb, Object)
- Preposition 在 added to all Location vocabulary
- Speech Synthesis (Read Aloud 朗读) in standard Mandarin (zh-CN)
- Sentence Line with draggable slots and punctuation tray
- Full Vocabulary Selector covering Lessons 1 through 11
- Offline persistence (localStorage)

Designed for middle school Chinese language classrooms.
